<footer class="bg-dark text-white mt-5">
        <div class="container py-4">
            <div class="row">
                <div class="col-md-6">
                    <h5>About Us</h5>
                    <p>Your trusted food partner since 2023</p>
                </div>
                <div class="col-md-6">
                    <h5>Contact</h5>
                    <p>Email: info@foodstore.com<br>Phone: +1 234 567 890</p>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>